%display all matrices
space=' ';
%first model
fprintf('All Metrics for First Model: ');
disp(space);
fprintf('D Prime = %f', FirstModel_dprime);
disp(space);
fprintf('EER = %f', FirstModel_EER);
disp(space);
fprintf('HTER = %f', FirstModel_HTER);
disp(space);
%second model
fprintf('All Metrics for Second Model: ');
disp(space);
fprintf('D Prime = %f', SecondModel_dprime);
disp(space);
fprintf('EER = %f', SecondModel_EER);
disp(space);
fprintf('HTER = %f', SecondModel_HTER);
disp(space);